STANT RIDER — REAL DATABASE STARTER

1. Create a free Supabase project.
2. Open SQL Editor and run supabase_setup.sql.
3. Copy the project's public URL and anon/publishable key.
4. The supplied index.html and admin.html are already connected to this project using the public publishable key.
5. Create your admin user in Supabase Authentication.
6. IMPORTANT: the admin RLS policies must already be created in your project as instructed in chat. They restrict order reads/updates to the admin user.
7. Upload index.html to GitHub Pages. Keep admin.html separate/unlinked if desired.

Never put the Supabase service-role key in browser code or GitHub.
